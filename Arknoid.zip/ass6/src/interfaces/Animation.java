package interfaces;
//315589507
import biuoop.DrawSurface;
/**
 * this interface named Animation is for creating a Animation interface.
 * @author Ron Solomon
 */
public interface Animation {
    /**
     * this method draw one frame of the animation on the given DrawSurface.
     * @param d is the surface
     */
    void doOneFrame(DrawSurface d);
    /**
     * this method let us know when to stop the animation.
     * @return true or false.
     */
    boolean shouldStop();
}
