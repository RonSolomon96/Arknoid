package interfaces;
//315589507

import basicshapes.Ball;
import gameobjects.Block;

/**
 * this interface named HitListener is for creating a HitListener interface.
 * this  interface indicate that objects that implement it send notifications when they are being hit.
 * @author Ron Solomon
 */
public interface HitListener {
/** This method is called whenever the beingHit object is hit.
     The hitter parameter is the Ball that's doing the hitting.
 * @param beingHit is the block that has been hit.
 * @param hitter is the hitter ball .
 */
    void hitEvent(Block beingHit, Ball hitter);
}
