package interfaces;
//ID : 315589507

import basicshapes.Ball;
import basicshapes.Point;
import basicshapes.Rectangle;
import basicshapes.Velocity;

/**
 * this interface named collidable is for creating a Point object.
 * A point has an x and a y value, and can measure the distance to other points, and if it is equal to another point.
 * @author Ron Solomon
 */
public interface Collidable {
    /**
     @return eturn the "collision shape" of the object.
     */
    Rectangle getCollisionRectangle();
    /**
     Notify the object that we collided with it at collisionPoint with
     a given velocity.
     The return is the new velocity expected after the hit (based on
     the force the object inflicted on us).
     @param collisionPoint the collision point.
     @param currentVelocity the current velocity.
     @param hitter is the ball that hits.
     @return new velocity.
     */
    Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity);
}
