//315589507
import biuoop.GUI;
import gameplay.AnimationRunner;
import gameplay.GameFlow;
import interfaces.LevelInformation;
import levels.Level1;
import levels.Level2;
import levels.Level3;
import levels.Level4;
import java.util.ArrayList;
import java.util.List;


/**
 * this class named Ass3Game is for creating a game object.
 * initialize it and run it.
 * @author Ron Solomon
 */
public class Ass6Game {
    /**
     * this main method runs the game.
     *
     * @param args .
     */
    public static void main(String[] args) {
        GUI gui = new GUI("Arkanoid", 800, 600);
        AnimationRunner ar = new AnimationRunner(gui, 60);
        biuoop.KeyboardSensor ks = gui.getKeyboardSensor();
        GameFlow g = new GameFlow(ar, ks, gui);
        List<LevelInformation> levels = new ArrayList<>();
        int count = 0;
        for (String s : args) {
            if (s.equals("1")) {
                levels.add(new Level1());
                count++;
            }
            if (s.equals("2")) {
                levels.add(new Level2());
                count++;
            }
            if (s.equals("3")) {
                levels.add(new Level3());
                count++;
            }
            if (s.equals("4")) {
                levels.add(new Level4());
                count++;
            }
        }
            if (count == 0) {
                levels.add(new Level1());
                levels.add(new Level2());
                levels.add(new Level3());
                levels.add(new Level4());
            }
            g.runLevels(levels);
    }
}

