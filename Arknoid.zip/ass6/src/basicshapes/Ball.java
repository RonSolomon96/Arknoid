package basicshapes;
//ID : 315589507
import biuoop.DrawSurface;
import gameplay.CollisionInfo;
import gameplay.GameLevel;
import gameplay.GameEnvironment;
import interfaces.Sprite;

/**
 * this class named Ball is for creating a Ball object.
 * a ball has a center point,radius,color,and velocity.
 * this class includes methods like ,get and set velocity ,get radius ,draw the ball on a surface.
 * @author Ron Solomon
 */
public class Ball implements Sprite {
    private Point center;
    private int r;
    private java.awt.Color color;
    private Velocity v;
    private GameEnvironment gameEnvironment;
    // constructor

    /**
     * this method gets 3 variables center radius and color.
     * the method is the constructor of the ball.
     *
     * @param center is the center point of the ball.
     * @param r      is the radius of the ball .
     * @param color  is the color of the ball .
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = center;
        this.color = color;
        this.r = r;
        this.v = new Velocity(0, 0);
        this.gameEnvironment = new GameEnvironment();
    }

    /**
     * this method gets 4 variables x y  radius and color.
     * the method is the constructor of the ball.
     *
     * @param x     is the x of the center point of the ball.
     * @param y     is the y of the center point of the ball.
     * @param r     is the radius of the ball .
     * @param color is the color of the ball .
     */
    public Ball(int x, int y, int r, java.awt.Color color) {
        this.center = new Point(x, y);
        this.color = color;
        this.r = r;
        this.v = new Velocity(0, 0);
        this.gameEnvironment = new GameEnvironment();
    }

    /**
     * this method gets 4 variables center radius and color.
     * the method is the constructor of the ball.
     *
     * @param center is the center point of the ball.
     * @param r      is the radius of the ball .
     * @param color  is the color of the ball .
     * @param v      is the velocity of the ball .
     */
    public Ball(Point center, int r, java.awt.Color color, Velocity v) {
        this.center = center;
        this.color = color;
        this.r = r;
        this.v = v;
        this.gameEnvironment = new GameEnvironment();
    }

    /**
     * this method gets 5 variables center radius and color.
     * the method is the constructor of the ball.
     *
     * @param x     is the x of the center point of the ball.
     * @param y     is the y of the center point of the ball.
     * @param r     is the radius of the ball .
     * @param color is the color of the ball .
     * @param v     is the velocity of the ball .
     */
    public Ball(int x, int y, int r, java.awt.Color color, Velocity v) {
        this.center = new Point(x, y);
        this.color = color;
        this.r = r;
        this.v = v;
        this.gameEnvironment = new GameEnvironment();
    }
    // accessors

    /**
     * @return the x value of the center point
     */
    public int getX() {
        return (int) this.center.getX();
    }

    /**
     * @return the y value of the center point
     */
    public int getY() {
        return (int) this.center.getY();
    }

    /**
     * @return the radius of the ball.
     */
    public int getSize() {
        return this.r;
    }

    /**
     * @return the color of the ball.
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    /**
     * this method draw the ball on the given DrawSurface.
     *
     * @param surface is the surface of the ball .
     */
    @Override
    public void drawOn(DrawSurface surface) {
        surface.setColor(Ball.this.getColor());
        surface.fillCircle(this.getX(), this.getY(), this.getSize());
    }

    /**
     * set game environment.
     *
     * @param g is the game environment of the ball .
     */
    public void setGameEnvironment(GameEnvironment g) {
        this.gameEnvironment = g;
    }

    /**
     * this method sets a new velocity to the ball.
     *
     * @param v1 is the Velocity of the ball .
     */
    public void setVelocity(Velocity v1) {
        this.v = v1;
    }


    /**
     * this method sets a new velocity to the ball.
     *
     * @param dx is the x axis Velocity of the ball .
     * @param dy is the y axis Velocity of the ball .
     */
    public void setVelocity(double dx, double dy) {
        this.v = new Velocity(dx, dy);
    }
    /**
     * set color.
     * @param c is the color.
     */
    public void setColor(java.awt.Color c) {
        this.color = c;
    }

    /**
     * @return the velocity of the ball.
     */
    public Velocity getVelocity() {
        return this.v;
    }
    /**
     * this method sets a new center point according to the velocity of the ball.
     * and changes the velocity according to the collisions.
     */
    public void moveOneStep() {
        Line trajectory = new Line(this.center, this.getVelocity().applyToPoint(this.center));
        //get collision info
        CollisionInfo info = this.gameEnvironment.getClosestCollision(trajectory);
        if (info == null) {
            this.center = this.getVelocity().applyToPoint(this.center);
            return;
        }
        double epsilon = Math.pow(10, -10);
        if (Math.abs(this.center.getY() - info.collisionPoint().getY()) < epsilon
                || Math.abs(this.center.getX() - info.collisionPoint().getX()) < epsilon) {

            if (this.v.getDy() > 0) {
                this.center = new Point(this.center.getX(), this.center.getY() - 0.1);
            }
            if (this.v.getDy() < 0) {
                this.center = new Point(this.center.getX(), this.center.getY() + 0.1);
            }
            if (this.v.getDx() > 0) {
                this.center = new Point(this.center.getX() - 0.1, this.center.getY());
            }
            if (this.v.getDx() < 0) {
                this.center = new Point(this.center.getX() + 0.1, this.center.getY());
            }
        }
        this.setVelocity(info.collisionObject().hit(this, info.collisionPoint(), this.getVelocity()));
    }
    /**
     * this method move the ball one step.
     */
    @Override
    public void timePassed() {
        this.moveOneStep();
    }
    /**
     * Add the ball to the game.
     * @param g the game
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }
    /**
     * remove the ball to the game.
     * @param g the game
     */
    public void removeFromGame(GameLevel g) {
        g.removeSprite(this);
    }
}

