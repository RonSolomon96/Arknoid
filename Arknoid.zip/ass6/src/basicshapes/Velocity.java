package basicshapes;
//ID : 315589507
/**
 * this class named Velocity and creates a velocity field for the ball.
 * the class includes methods to set and get the velocity for the ball.
 * @author Ron Solomon
 */
public class Velocity {
    private double dx;
    private double dy;
    // constructor
    /**
     * this method gets tew double variables dx and dy
     * which represents the progress of the ball along the axis and insert them to the velocity object.
     * @param dx is for the x axis .
     * @param dy is for the y axis.
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }
    /**
     * this method.
     * @return dx the x value of the velocity.
     */
    public double getDx() {
        return this.dx;
    }
    /**
     * this method.
     * @return dy the y value of the velocity.
     */
    public double getDy() {
        return this.dy;
    }
    /**
     * this method Takes a point with position (x,y) and return a new point
     * with position (x+dx, y+dy).
     * @param p is the start point.
     * @return the new point newP.
     */
    public Point applyToPoint(Point p) {
        Point newP = new Point(p.getX() + this.getDx(), p.getY() + this.getDy());
        return newP;
    }
    /**
     * this method gets an angle and speed and coverts it to dx and dy speed .
     * @param angle is the angle of the speed.
     * @param speed is the progress on the axis.
     * @return the new velocity .
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        double dx =  speed * Math.sin(Math.toRadians(angle));
        double dy =  (-1) * speed *  Math.cos(Math.toRadians(angle));
        return new Velocity(dx, dy);
    }
}


