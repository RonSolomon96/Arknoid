package basicshapes;
//ID : 315589507
/**
 * this class named Point is for creating a Point object.
 * A point has an x and a y value, and can measure the distance to other points, and if it is equal to another point.
 * @author Ron Solomon
 */
public class Point {
    // fields
    private double x;
    private double y;
    // constructor

    /**
     * this method gets two double type variables x and y.
     * which represents the x and the y of the  point of  and insert them to the Point object.
     * @param x is the x axis value of the point .
     * @param y is the y axis value of the point .
     */
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /**
     * @param other is the other point.
     * @return the distance of this point to the other point
     */
    public double distance(Point other) {
        double x1, x2, y1, y2;
        x1 = this.x;
        y1 = this.y;
        x2 = other.getX();
        y2 = other.getY();
        return Math.sqrt(((x1 - x2) * (x1 - x2)) + ((y1 - y2) * (y1 - y2)));

    }

    /**
     * this method check if  both points are equals.
     *
     * @param other is the other point  .
     * @return true is the points are equal, false otherwise
     */
    public boolean equals(Point other) {
        double x1, x2, y1, y2;
        x1 = this.x;
        y1 = this.y;
        x2 = other.getX();
        y2 = other.getY();
        double epsilon = Math.pow(10, -13);
        return Math.abs(x1 - x2) < epsilon && Math.abs(y1 - y2) < epsilon;
    }

    /**
     * @return the x value of this point
     */
    // Return the x and y values of this point
    public double getX() {
        return this.x;
    }

    /**
     * @return the y value of this point
     */
    public double getY() {
        return this.y;
    }
}

