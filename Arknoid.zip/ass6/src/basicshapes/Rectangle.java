package basicshapes;
//ID : 315589507
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * this class named Rectangle is for creating a Rectangle object.
 * a Rectangle connects 4 points ,a upperLeft point a upperRight point a lowerLeft point and an end lowerRight.
 * Rectangle have height and width, and may intersect with other lines.
 * @author Ron Solomon
 */
public class Rectangle {
    // fields
    private double width;
    private double height;
    private Point upperLeft;
    private Point upperRight;
    private Point lowerLeft;
    private Point lowerRight;
    private java.awt.Color color;
    // constructor

    /**
     * this method gets double type variables width and height.
     * and a start point upper left.
     * @param width is the x axis value of the rectangle .
     * @param height is the y axis value of the rectangle .
     * @param upperLeft is the upper left point of the rectangle .
     */
    // Create a new rectangle with location and width/height.
    public Rectangle(Point upperLeft, double width, double height) {
        this.height = height;
        this.width = width;
        this.upperLeft = upperLeft;
        this.lowerLeft = new Point(upperLeft.getX(), (upperLeft.getY() + height));
        this.upperRight = new Point((upperLeft.getX() + width), upperLeft.getY());
        this.lowerRight = new Point((upperLeft.getX() + width), (upperLeft.getY() + height));
        this.color = Color.black;
    }
    /**
     Return a (possibly empty) List of intersection points
     with the specified line.
     * @param line is the x axis value of the rectangle .
     * @return  List of intersection points
     */
    public java.util.List<Point> intersectionPoints(Line line) {
        List<Point> plist = new ArrayList<>();
        //get the intersection points.
        Point p1 = line.intersectionWith(new Line(upperLeft, upperRight));
        Point p2 = line.intersectionWith(new Line(upperLeft, lowerLeft));
        Point p3 = line.intersectionWith(new Line(lowerRight, upperRight));
        Point p4 = line.intersectionWith(new Line(lowerLeft, lowerRight));
        //check if the intersection points are not null ,if so add them to the list.
        if (p1 !=  null) {
            plist.add(p1);
        }
        if (p2 !=  null && !(plist.contains(p2))) {
            plist.add(p2);
        }
        if (p3 !=  null && !(plist.contains(p3))) {
            plist.add(p3);
        }
        if (p4 !=  null && !(plist.contains(p4))) {
            plist.add(p4);
        }
        return plist;
    }
    /**
     * @return  the width of the rectangle
     */
    public double getWidth() {
        return this.width;
    }
    /**
     * @return  the height of the rectangle
     */
    public double getHeight() {
        return this.height;
    }

    /**
     * @param p the new upper-left point of the rectangle.
     */
    public void setUpperLeft(Point p) {
        this.upperLeft = p;
    }
    /**
     * sets new rec values.
     * @param ul upper-left point of the rectangle.
     * @param step the step.
     */
    public void setFullRec(Point ul, int step) {
        this.upperLeft = new Point(ul.getX() + step, ul.getY());
        this.lowerLeft = new Point(upperLeft.getX(), (upperLeft.getY() + this.height));
        this.upperRight = new Point((upperLeft.getX() + this.width), upperLeft.getY());
        this.lowerRight = new Point((upperLeft.getX() + this.width), (upperLeft.getY() + this.height));
    }
    /**
     * @return  the upper-left point of the rectangle.
     */
    public Point getUpperLeft() {
        return this.upperLeft;
    }
    /**
     * @return  the upper-right point of the rectangle.
     */
    public Point getUpperRight() {
        return this.upperRight;
    }
    /**
     * @return  the lower-left point of the rectangle.
     */
    public Point getLowerLeft() {
        return this.lowerLeft;
    }
    /**
     * @return  the lower-right point of the rectangle.
     */
    public Point getLowerRight() {
        return this.lowerRight;
    }
    /**
     * set color.
     * @param c is the color.
     */
    public void setColor(java.awt.Color c) {
        this.color = c;
    }
}

