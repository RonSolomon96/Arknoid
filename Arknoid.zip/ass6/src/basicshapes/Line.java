package basicshapes;
//ID : 315589507
import java.util.List;

/**
 * this class named Line is for creating a Line object.
 * a line connects two points ,a start point and an end point. Lines have lengths, and may intersect with other lines.
 * It can also tell if it is the same as another line segment.
 * this class includes methods like ,intersections points of 2 lines ,equality of lines ,lines equations ,inclination.
 * @author Ron Solomon
 */

public class Line {
    private Point start;
    private Point end;

    // constructors

    /**
     * this method gets tow point type variables start and end.
     * which represents the start and the end point of a line and insert them to the line object
     *
     * @param start is the start point .
     * @param end   is the end point.
     */
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
    }

    /**
     * this method gets 4 double type variables x1 x2 y1 y2.
     * which represents the start and the end point of a line and insert them to the line object
     *
     * @param x1 is the x of the start point .
     * @param y1 is the y of the start point.
     * @param x2 is the x of the end point .
     * @param y2 is the y of the end point.
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.start = new Point(x1, y1);
        this.end = new Point(x2, y2);
    }

    /**
     * this method Return the inclination of the line.
     *
     * @return m ,the inclination
     */
    public double inclination() {
        double m;
        m = (end.getY() - start.getY()) / (end.getX() - start.getX());
        return m;
    }

    /**
     * this method Return the variable of the line equation.
     *
     * @return b ,the variable of the line equation
     */
    public double getB() {
        double b;
        b = start.getY() - (start.getX() * this.inclination());
        return b;
    }

    /**
     * @return the length of the line
     */
    // Return the length of the line
    public double length() {
        return (this.start.distance(end));
    }

    /**
     * @return mid , the middle point of the line.
     */
    public Point middle() {
        double x1, x2, y1, y2;
        x1 = this.start.getX();
        x2 = this.end.getX();
        y1 = this.start.getY();
        y2 = this.end.getY();
        Point mid = new Point((x1 + x2) / 2, (y1 + y2) / 2);
        return mid;
    }

    /**
     * @return the start point of the line
     */
    public Point start() {
        return this.start;
    }

    /**
     * @return the end point of the line
     */
    public Point end() {
        return this.end;
    }

    /**
     * this method check if a point is on both lines.
     *
     * @param other is the other line  .
     * @param p     is the point.
     * @return true if the point is on both line and false else.
     */
    public boolean checkPoint(Line other, Point p) {
        //d represents distance
        double d1, d2, d3, d4, d5, d6, epsilon;
        d1 = p.distance(this.start);
        d2 = p.distance(this.end);
        d3 = this.start.distance(this.end);
        d4 = p.distance(other.start);
        d5 = p.distance(other.end);
        d6 = other.start.distance(other.end);
        epsilon = Math.pow(10, -13);
        // this checks if the number is closer to 0 than epsilon,
        // if true, the distance is equal and the point is on the line.
        return Math.abs((d1 + d2) - d3) < epsilon && Math.abs((d4 + d5) - d6) < epsilon;
    }

    /**
     * this method check if  both lines intersect.
     *
     * @param other is the other line  .
     * @return true if the lines intersect, false otherwise
     */
    public boolean isIntersecting(Line other) {
        //m is for inclination ,b is the variable of the line equation.
        double m1, m2, b1, b2, x, y;
        m1 = this.inclination();
        b1 = this.getB();
        m2 = other.inclination();
        b2 = other.getB();
        /* if the line is parallel to the y axis and the other is not
        we get the intersection point .
         */
        if (this.start.getX() == this.end.getX() && other.start.getX() != other.end.getX()) {
            x = this.start.getX();
            y = (m2 * x) + b2;
            Point interPoint = new Point(x, y);
            return checkPoint(other, interPoint);
        }
        /* if the line is parallel to the y axis and the other is not
        we get the intersection point .
         */
        if (this.start.getX() != this.end.getX() && other.start.getX() == other.end.getX()) {
            x = other.start.getX();
            y = (m1 * x) + b1;
            Point interPoint = new Point(x, y);
            return checkPoint(other, interPoint);
        }
        /* if both lines are parallel to the y axis
        we get the intersection point .
         */
        if (this.start.getX() == this.end.getX() && other.start.getX() == other.end.getX()) {
            //check if one of them is a point
            if (this.start.equals(this.end)) {
                return checkPoint(other, this.start);
            }
            //check if one of them is a point
            if (other.start.equals(other.end)) {
                return checkPoint(other, other.start);
            }
            /* check if both lines are touching the same point but do not merge
             with each other .
            */
            if (this.start.equals(other.start) || this.start.equals(other.end) || this.end.equals(other.start)
                    || this.end.equals(other.end)) {
                return true;
            }
            return false;
        }
        //if the line are parallel return false .
        if (m1 == m2 && b1 != b2) {
            return false;
        }
        //if both lines has the same equation.
        if (m1 == m2 && b1 == b2) {
            //check if the lines has points in common
            return this.checkPoint(other, other.start) || this.checkPoint(other, other.end)
                    || other.checkPoint(this, this.start) || other.checkPoint(this, this.end);
        }
        //check if both lines has the same inclination.
        //and get the intersection point
        if (m1 != m2) {
            x = (b2 - b1) / (m1 - m2);
            y = (m1 * x) + b1;
            Point interPoint = new Point(x, y);
            return checkPoint(other, interPoint);
        }
        return true;
    }

    /**
     * this method Returns the intersection point if the lines intersect,
     * and null otherwise.
     *
     * @param other is the other line  .
     * @return the intersection point if the lines intersect,
     * * and null otherwise.
     */
    public Point intersectionWith(Line other) {
        if (this.isIntersecting(other)) {
            if (this.start.equals(this.end) && (other.start.equals(other.end))) {
                return this.start;
            }
            double x, y, m1, m2, b1, b2;
            m1 = this.inclination();
            b1 = this.getB();
            m2 = other.inclination();
            b2 = other.getB();
            //get the x and y values .
            x = (b2 - b1) / (m1 - m2);
            y = (m1 * x) + b1;
            if (this.start.getX() == this.end.getX() && other.start.getX() != other.end.getX()) {
                x = this.start.getX();
                y = (m2 * x) + b2;
            }
            if (this.start.getX() != this.end.getX() && other.start.getX() == other.end.getX()) {
                x = other.start.getX();
                y = (m1 * x) + b1;
            }
            //if both lines has the same equation or both are parallel to the y axis .
            if ((m1 == m2 && b1 == b2)
                    || (this.start.getX() == this.end.getX() && other.start.getX() == other.end.getX())) {
                /* check all the cases in which the line merge
                if they have more then one intersection point return null  */
                if (this.checkPoint(other, other.start) && this.checkPoint(other, other.end)
                        && !(other.start.equals(other.end))
                        || other.checkPoint(this, this.start) && other.checkPoint(this, this.end)
                        && !(this.start.equals(this.end))
                        || this.checkPoint(other, other.start) && other.checkPoint(this, this.end)
                        && !(other.start.equals(this.end))
                        || this.checkPoint(other, other.end) && other.checkPoint(this, this.start)
                        && !(other.end.equals(this.start))
                        || this.checkPoint(other, other.end) && other.checkPoint(this, this.end)
                        && !(other.end.equals(this.end))
                        || this.checkPoint(other, other.start) && other.checkPoint(this, this.start)
                        && !(other.start.equals(this.start))) {
                    return null;
                }
            }
            /* check if the lines has a mutual touching point and returns it */
            if (this.start.equals(this.end)) {
                return this.start;
            }
            if (other.start.equals(other.end)) {
                return other.end;
            }
            if (this.start.equals(other.start)) {
                return this.start;
            }
            if (this.start.equals(other.end)) {
                return this.start;
            }
            if (this.end.equals(other.start)) {
                return this.end;
            }
            if (this.end.equals(other.end)) {
                return this.end;
            }
            Point interPoint = new Point(x, y);
            return interPoint;
        } else {
            return null;
        }
    }

    /**
     * this method check if  both lines equals.
     *
     * @param other is the other line  .
     * @return true is the lines are equal, false otherwise
     */
    public boolean equals(Line other) {
        return this.start.equals(other.start) && this.end.equals(other.end);
    }

    /**
     * If this line does not intersect with the rectangle, return null.
     * Otherwise, return the closest intersection point to the
     * start of the line.
     *
     * @param rect is the rectangle  .
     * @return null or the closest intersection point to the
     * start of the line.
     */
    public Point closestIntersectionToStartOfLine(Rectangle rect) {
        List<Point> l1 = rect.intersectionPoints(this);
        if (l1.isEmpty()) {
            return null;
        } else {
            double minDist = this.start.distance(l1.get(0));
            int index = 0;
            for (int i = 0; i < l1.size(); i++) {
                double dist = this.start.distance(l1.get(i));
                if (dist < minDist) {
                    minDist = dist;
                    index = i;
                }
            }
            return l1.get(index);
        }
    }
}



