package gameobjects;
//ID : 315589507
import basicshapes.Ball;
import basicshapes.Point;
import basicshapes.Rectangle;
import basicshapes.Velocity;
import biuoop.DrawSurface;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import gameplay.GameLevel;
import interfaces.Collidable;
import interfaces.HitListener;
import interfaces.HitNotifier;
import interfaces.Sprite;

/**
 * this class named block is for creating a block object.
 * a block has a shape and collision points. two points
 * @author Ron Solomon
 */
public class Block implements Collidable, Sprite, HitNotifier {
    private Rectangle rec;
    private  java.awt.Color color;
    private List<HitListener> hitListeners;
    //constructor.
    /**
     * create a block .
     * @param rect is the rectangle that the block shape will have .
     */
    public Block(Rectangle rect) {
        this.rec = rect;
        this.color = Color.black;
        this.hitListeners = new ArrayList<>();
    }
    /**
     * @return  the "collision shape" of the object.
     */
    @Override
    public Rectangle getCollisionRectangle() {
        return this.rec;
    }
    /**
     * This method check where the hit happens and change the velocity accordingly.
     * @param collisionPoint the collision point.
     * @param  currentVelocity the current Velocity of the object.
     * @return  the new velocity  of the ball.
     */
    @Override
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        if (collisionPoint == null) {
            return currentVelocity;
        }
        this.notifyHit(hitter);
        double epsilon = Math.pow(10, -10);
        Velocity v1 = currentVelocity;
        //check if the collision is on the upper line of the rectangle
        if (Math.abs(collisionPoint.getY() - this.rec.getUpperLeft().getY()) < epsilon) {
            //change dy velocity
            v1 = new Velocity(currentVelocity.getDx(), -currentVelocity.getDy());
            return v1;
        }
        //check if the collision is on the lower line of the rectangle
        if (Math.abs(collisionPoint.getY() - this.rec.getLowerLeft().getY()) < epsilon) {
            //change dy velocity
            v1 = new Velocity(currentVelocity.getDx(), -currentVelocity.getDy());
            return v1;
        }
        //check if the collision is on the left line of the rectangle
        if (Math.abs(collisionPoint.getX() - this.rec.getUpperLeft().getX()) < epsilon) {
            //change dx velocity
            v1 = new Velocity(-currentVelocity.getDx(), currentVelocity.getDy());
            return v1;
        }
        //check if the collision is on the right line of the rectangle
        if (Math.abs(collisionPoint.getX() - this.rec.getUpperRight().getX()) < epsilon) {
            //change dx velocity
            v1 = new Velocity(-currentVelocity.getDx(), currentVelocity.getDy());
            return v1;
        }
        return v1;
    }
    /**
     * this method draw the rectangle on the given DrawSurface.
     * @param surface is the surface of the ball .
     */
    @Override
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.color);
        surface.fillRectangle((int) this.rec.getUpperLeft().getX(), (int) this.rec.getUpperLeft().getY(),
                (int) this.rec.getWidth(), (int) this.rec.getHeight());
        surface.setColor(Color.black);
        surface.drawRectangle((int) this.rec.getUpperLeft().getX(), (int) this.rec.getUpperLeft().getY(),
                (int) this.rec.getWidth(), (int) this.rec.getHeight());
    }
    /**
     * this method set the block color.
     * @param c is the color of the block .
     */
    public void setColor(Color c) {
        this.color = c;
    }

    /**
     * .
     */
    @Override
    public void timePassed() {
        return;
    }
    /**
     * Add the block to the game.
     * @param g the game
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }
    /**
     * remove the block to the game.
     * @param game the game
     */
    public void removeFromGame(GameLevel game) {
        game.removeCollidable(this);
        game.removeSprite(this);
    }

    @Override
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }

    @Override
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }
    /**
     * remove the block to the game.
     * @param hitter is the hitting ball.
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }
}
