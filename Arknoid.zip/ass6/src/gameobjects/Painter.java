package gameobjects;

import biuoop.DrawSurface;
import interfaces.Sprite;

/**
 * this class named Painter is for creating a Painter object.
 * paints on the screen
 * @author Ron Solomon
 */
public class Painter implements Sprite {
    private String script;
    private  int width;
    private int height;
    private int size;

    /**
     *  this method is the constructor.
     * @param width is the width
     * @param height is the height
     * @param size is the size
     * @param script is the script
     */
    public Painter(int width, int height, int size, String script) {
        this.height = height;
        this.script = script;
        this.size = size;
        this.width = width;
    }
    @Override
    public void drawOn(DrawSurface d) {
        d.drawText(width, height, script, size);
    }

    @Override
    public void timePassed() {

    }
}
