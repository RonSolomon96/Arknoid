package gameobjects;
//ID : 315589507

import basicshapes.Ball;
import basicshapes.Point;
import basicshapes.Rectangle;
import basicshapes.Velocity;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import java.awt.Color;
import gameplay.GameLevel;
import interfaces.Collidable;
import interfaces.Sprite;

/**
 * this class named Paddle is for creating a Paddle object.
 * is the player in the game. It is a rectangle that is controlled by the arrow keys
 * and moves according to the player key presses.
 * @author Ron Solomon
 */
public class Paddle implements Sprite, Collidable {
    // paddle size
    private int paddleWidth;
    //hit speed
    private static final int SPEED = 5;
    //one part of the paddle size
    private int partWidth;
    private int step;
    private biuoop.KeyboardSensor keyboard;
    private Rectangle rectangle;
    private  java.awt.Color color;
    // constructor
    /**
     * this method is the constructor of the paddle.
     * @param keyboard .
     * @param rec .
     */
    public Paddle(biuoop.KeyboardSensor keyboard, Rectangle rec) {
        this.rectangle = rec;
        this.keyboard = keyboard;
        this.color = Color.black;
    }
    /**
     * this method move the paddle.
     */
    public void moveLeft() {
        if (this.rectangle.getUpperLeft().getX() > 40) {
            this.rectangle.setFullRec(this.rectangle.getUpperLeft(), -step);
        }
    }
    /**
     * this method move the paddle.
     */
    public void moveRight() {
        if (this.rectangle.getUpperRight().getX() < 760) {
            this.rectangle.setFullRec(this.rectangle.getUpperLeft(), step);
        }
    }
    /**
     * this method set the paddle width.
     * @param width is the surface of the ball .
     */
    public void setPaddleWidth(int width) {
        this.paddleWidth = width;
        this.partWidth = (paddleWidth / 5);
    }
    /**
     * this method set the paddle color.
     * @param c is the surface of the ball .
     */
    public void setColor(Color c) {
        this.color = c;
    }
    /**
     * this method set the paddle step.
     * @param s is the step of the paddle .
     */
    public void setStep(int s) {
        this.step = s;
    }
    // Sprite
    /**
     * this method check if the arrow keys are pressed and move the paddle accordingly.
     */
    @Override
    public void timePassed() {
        if (this.keyboard.isPressed(KeyboardSensor.LEFT_KEY)) {
            this.moveLeft();
        }
        if (this.keyboard.isPressed(KeyboardSensor.RIGHT_KEY)) {
            this.moveRight();
        }
    }
    /**
     * this method draw the paddle.
     * @param d is the surface  .
     */
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(this.color);
        d.fillRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());
        d.setColor(Color.black);
        d.drawRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());
    }
    // Collidable
    /**
     * this method return the collision rectangle.
     */
    @Override
    public Rectangle getCollisionRectangle() {
        return this.rectangle;
    }
    /**
     * this method draw the paddle.
     * @param collisionPoint is the collision point.
     * @param currentVelocity is the current velocity.
     */
    @Override
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        if (collisionPoint == null) {
            return currentVelocity;
        }
        Velocity v1 = currentVelocity;
        double d = this.rectangle.getUpperLeft().getX() + paddleWidth - collisionPoint.getX();
        //check if the collision is on the left (part1) of the paddle
        if ((d < 5 * partWidth) && d > (4 * partWidth)) {
            //change velocity
            return Velocity.fromAngleAndSpeed(300, SPEED + 1);
        }
        //check if the collision is on the left (part2) of the paddle
        if (d < (4 * partWidth) + 1 && d > 3 * partWidth) {
            //return new velocity
            return Velocity.fromAngleAndSpeed(330, SPEED);
        }
        //check if the collision is on the middle part of the paddle
        if (d < (3 * partWidth) + 1 && d > 2 * partWidth) {
            //change dy velocity
            v1 = new Velocity(currentVelocity.getDx(), -currentVelocity.getDy());
            return v1;
        }
        //check if the collision is on the right (part3) of the paddle
        if (d < (2 * partWidth) + 1 && d > partWidth) {
            //change  velocity
            return Velocity.fromAngleAndSpeed(30, SPEED);
        }
        if (d < partWidth + 1) {
            //change dx velocity
            return Velocity.fromAngleAndSpeed(60, SPEED + 1);
        }
        return new Velocity(-v1.getDx(), v1.getDy());
    }
    /**
     * this method Add this paddle to the game.
     * @param g is the game .
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }
    /**
     * this method prints this paddle upper left point.
     */
    public void printPad() {
        System.out.println(this.rectangle.getUpperLeft().getX() + "," + this.rectangle.getUpperLeft().getY());
    }
}

