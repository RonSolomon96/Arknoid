package levels;
//315589507

import biuoop.DrawSurface;
import gameobjects.Block;
import interfaces.Sprite;
import java.awt.Color;

/**
 * this class named Background1 is for creating a Background1 object.
 * paint background.
 * @author Ron Solomon
 */
public class Background3 implements Sprite {
    private Block background;
    /**
     * this method is the constructor.
     */
    public Background3() {
    }
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(new Color(50, 120, 20));
        d.fillRectangle(0, 0, 800, 600);
        //draw traffic lights
        d.setColor(Color.lightGray);
        d.drawLine(180, 160, 180, 100);
        d.fillRectangle(100, 320, 160, 240);
        d.setColor(Color.darkGray);
        d.fillRectangle(140, 220, 80, 100);
        d.setColor(Color.gray);
        d.fillRectangle(160, 160, 40, 60);
        d.setColor(new Color(220, 120,  50));
        d.fillCircle(180, 100, 15);
        d.setColor(new Color(200, 50,  50));
        d.fillCircle(180, 100, 10);
        d.setColor(Color.white);
        d.fillCircle(180, 100, 5);
        d.setColor(Color.black);
        d.drawCircle(180, 100, 15);
        int x = 100;
        int y = 320;
        for (int i = 0; i < 8; i++) {
           // d.fillRectangle(x, 320, 10, 240);
            d.fillRectangle(100, y, 160, 20);
            x = x + 40;
            y = y + 40;
        }
    }
    @Override
    public void timePassed() {

    }
}
