package levels;
//315589507
import basicshapes.Point;
import basicshapes.Rectangle;
import basicshapes.Velocity;
import gameobjects.Block;
import interfaces.LevelInformation;
import interfaces.Sprite;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
/**
 * this class named Level2 is for creating a Level2 object.
 * initialize it and run it.
 * @author Ron Solomon
 */
public class Level2 implements LevelInformation {
    private  int numberOfBalls;
    private  List<Velocity> initialBallVelocities;
    private  int paddleSpeed;
    private  int numberOfBlocksToRemove;
    private  int paddleWidth;
    private  String levelName;
    private  Sprite background;
    private  List<Block> blocks;

    /**
     *  this is the constructor.
     */
    public Level2() {
        this.numberOfBalls = 10;
        this.initialBallVelocities = new ArrayList<>();
        this.paddleSpeed = 5;
        this.numberOfBlocksToRemove = 15;
        this.paddleWidth = 400;
        this.levelName = "Level 2";
        this.background = new Background2();
        this.blocks = new ArrayList<>();
    }
    @Override
    public int numberOfBalls() {
        return numberOfBalls;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        int deg = 315;
        for (int i = 0; i < this.numberOfBalls; i++) {
            this.initialBallVelocities.add(Velocity.fromAngleAndSpeed(deg, 5));
            deg = deg + 10;
        }
        return this.initialBallVelocities;
    }

    @Override
    public int paddleSpeed() {
        return this.paddleSpeed;
    }

    @Override
    public int paddleWidth() {
        return this.paddleWidth;
    }

    @Override
    public String levelName() {
        return this.levelName;
    }

    @Override
    public Sprite getBackground() {
        return this.background;
    }

    @Override
    public List<Block> blocks() {
        //set a colors array
        Color[] colors = new Color[5];
        colors[0] = Color.red;
        colors[1] = Color.yellow;
        colors[2] = Color.green;
        int x = 712;
        int y = 220;
        for (int i = 0; i < 15; i++) {
            Block block = new Block(new Rectangle(new Point(x, y), 48, 20));
            block.setColor(colors[i % 3]);
            x = x - 48;
            this.blocks.add(block);
        }
        return this.blocks;
    }
    @Override
    public int numberOfBlocksToRemove() {
        return this.numberOfBlocksToRemove;
    }

    @Override
    public Color ballColor() {
        return Color.black;
    }
}
