package levels;
//315589507
import basicshapes.Point;
import basicshapes.Rectangle;
import basicshapes.Velocity;
import gameobjects.Block;
import interfaces.LevelInformation;
import interfaces.Sprite;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
/**
 * this class named Level1 is for creating a Level1 object.
 * initialize it and run it.
 * @author Ron Solomon
 */
public class Level3 implements LevelInformation {
    private  int numberOfBalls;
    private  List<Velocity> initialBallVelocities;
    private  int paddleSpeed;
    private  int numberOfBlocksToRemove;
    private  int paddleWidth;
    private  String levelName;
    private  Sprite background;
    private  List<Block> blocks;

    /**
     *  this is the constructor.
     */
    public Level3() {
        this.numberOfBalls = 2;
        this.initialBallVelocities = new ArrayList<>();
        this.paddleSpeed = 5;
        this.numberOfBlocksToRemove = 40;
        this.paddleWidth = 100;
        this.levelName = "Level 3";
        this.background = new Background3();
        this.blocks = new ArrayList<>();
    }
    @Override
    public int numberOfBalls() {
        return numberOfBalls;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        int x = 45;
        for (int i = 0; i < this.numberOfBalls; i++) {
            this.initialBallVelocities.add(Velocity.fromAngleAndSpeed(-x, 5));
            x = -x;
        }
        return this.initialBallVelocities;
    }

    @Override
    public int paddleSpeed() {
        return this.paddleSpeed;
    }

    @Override
    public int paddleWidth() {
        return this.paddleWidth;
    }

    @Override
    public String levelName() {
        return this.levelName;
    }

    @Override
    public Sprite getBackground() {
        return this.background;
    }

    @Override
    public List<Block> blocks() {
        //set a colors array
        Color[] colors = new Color[5];
        colors[0] = Color.red;
        colors[1] = Color.yellow;
        colors[2] = Color.green;
        colors[3] = Color.gray;
        colors[4] = Color.blue;
        for (int i = 0; i < 5; i++) {
            int x = 710;
            int y = 120;
            for (int j = 0; j < 10 - i; j++) {
                Block block = new Block(new Rectangle(new Point(x, y + (i * 20)), 50, 20));
                block.setColor(colors[i]);
                x = x - 50;
                this.blocks.add(block);
            }
        }
        return this.blocks;
    }
    @Override
    public int numberOfBlocksToRemove() {
        return this.numberOfBlocksToRemove;
    }

    @Override
    public Color ballColor() {
        return Color.white;
    }
}
