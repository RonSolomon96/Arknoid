package levels;
//315589507
import biuoop.DrawSurface;
import interfaces.Sprite;
import java.awt.Color;

/**
 * this class named Background1 is for creating a Background1 object.
 * paint background.
 * @author Ron Solomon
 */
public class Background4 implements Sprite {
    /**
     * this method is the constructor.
     */
    public Background4() {
    }
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(Color.cyan);
        d.fillRectangle(0, 0, 800, 600);
      //draw lines
        d.setColor(Color.white);
        int x = 120;
        for (int i = 0; i < 11; i++) {
            d.drawLine(x, 380, (x - 40), 600);
            x = x + 10;
        }
        x = 500;
        for (int i = 0; i < 11; i++) {
            d.drawLine(x, 440, (x - 60), 600);
            x = x + 10;
        }
        d.setColor(Color.gray);
        d.fillCircle(520, 440, 30);
        d.fillCircle(555, 455, 30);
        d.fillCircle(490, 460, 30);
        d.fillCircle(150, 360, 30);
        d.fillCircle(185, 375, 30);
        d.fillCircle(120, 380, 30);
        d.setColor(Color.lightGray);
        d.fillCircle(520, 460, 30);
        d.fillCircle(580, 455, 30);
        d.fillCircle(150, 380, 30);
        d.fillCircle(210, 375, 30);
    }

    @Override
    public void timePassed() {

    }
}