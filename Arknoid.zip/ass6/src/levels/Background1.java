package levels;

import basicshapes.Point;
import basicshapes.Rectangle;
import biuoop.DrawSurface;
import gameobjects.Block;
import interfaces.Sprite;

import java.awt.*;

/**
 * this class named Background1 is for creating a Background1 object.
 * paint background.
 * @author Ron Solomon
 */
public class Background1 implements Sprite {
    /**
     * this method is the constructor.
     */
    public Background1() {
    }
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(Color.black);
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(Color.blue);
        d.drawCircle(400, 215, 100);
        d.drawCircle(400, 215, 70);
        d.drawCircle(400, 215, 40);
        d.drawLine(410, 215, 550, 215);
        d.drawLine(390, 215, 250, 215);
        d.drawLine(400, 350, 400, 215);
        d.drawLine(400, 75, 400, 215);
    }

    @Override
    public void timePassed() {

    }
}
