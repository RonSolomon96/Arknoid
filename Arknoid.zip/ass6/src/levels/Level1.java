package levels;

import basicshapes.Point;
import basicshapes.Rectangle;
import basicshapes.Velocity;
import gameobjects.Block;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
/**
 * this class named Level1 is for creating a Level1 object.
 * initialize it and run it.
 * @author Ron Solomon
 */
public class Level1 implements LevelInformation {
    private final int numberOfBalls;
    private final List<Velocity> initialBallVelocities;
    private final int paddleSpeed;
    private final int numberOfBlocksToRemove;
    private final int paddleWidth;
    private final String levelName;
    private final Sprite background;
    private final List<Block> blocks;
    private final Color ballColor;

    /**
     *  this is the constructor.
     */
    public Level1() {
        this.ballColor = Color.white;
        this.numberOfBalls = 1;
        this.initialBallVelocities = new ArrayList<>();
        this.initialBallVelocities.add(new Velocity(0, -4));
        this.paddleSpeed = 5;
        this.numberOfBlocksToRemove = 1;
        this.paddleWidth = 100;
        this.levelName = "Level 1";
        this.background = new Background1();
        this.blocks = new ArrayList<>();
        Block b1 = new Block(new Rectangle(new Point(385, 200), 30, 30));
        b1.setColor(Color.red);
        this.blocks.add(b1);
    }
    @Override
    public int numberOfBalls() {
        return numberOfBalls;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        return this.initialBallVelocities;
    }

    @Override
    public int paddleSpeed() {
        return this.paddleSpeed;
    }

    @Override
    public int paddleWidth() {
        return this.paddleWidth;
    }

    @Override
    public String levelName() {
        return this.levelName;
    }

    @Override
    public Sprite getBackground() {
        return this.background;
    }

    @Override
    public List<Block> blocks() {
        return this.blocks;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return this.numberOfBlocksToRemove;
    }

    @Override
    public Color ballColor() {
        return this.ballColor;
    }
}
