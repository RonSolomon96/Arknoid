package levels;
//315589507
import basicshapes.Point;
import basicshapes.Rectangle;
import biuoop.DrawSurface;
import gameobjects.Block;
import interfaces.Sprite;
import java.awt.Color;

/**
 * this class named Background1 is for creating a Background1 object.
 * paint background.
 * @author Ron Solomon
 */
public class Background2 implements Sprite {
    private Block background;
    /**
     * this method is the constructor.
     */
    public Background2() {
        this.background = new Block(new Rectangle(new Point(0, 0), 800, 600));
    }
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(Color.white);
        d.fillRectangle(0, 0, 800, 600);
        //draw road
        d.setColor(Color.darkGray);
        d.fillRectangle(260, 340, 440, 160);
        d.setColor(Color.white);
        d.fillRectangle(300, 400, 80, 20);
        d.fillRectangle(440, 400, 80, 20);
        d.fillRectangle(580, 400, 80, 20);
        d.setColor(Color.black);
        d.drawRectangle(260, 340, 440, 160);
        d.drawRectangle(300, 400, 80, 20);
        d.drawRectangle(440, 400, 80, 20);
        d.drawRectangle(580, 400, 80, 20);
        //draw traffic lights
        d.setColor(Color.darkGray);
        d.fillRectangle(80, 460, 80, 60);
        d.setColor(Color.gray);
        d.fillRectangle(100, 400, 40, 60);
        d.setColor(Color.gray);
        d.fillRectangle(110, 360, 20, 40);
        d.setColor(Color.lightGray);
        d.fillRectangle(115, 320, 10, 40);
        d.setColor(Color.lightGray);
        d.fillRectangle(125, 320, 60, 5);
        d.setColor(new Color(40, 40, 40));
        d.fillRectangle(185, 300, 40, 90);
        d.setColor(Color.green);
        d.fillCircle(205, 315, 10);
        d.setColor(Color.yellow);
        d.fillCircle(205, 345, 10);
        d.setColor(Color.red);
        d.fillCircle(205, 375, 10);
    }

    @Override
    public void timePassed() {

    }
}