package gameplay;
//315589507

import biuoop.DrawSurface;
import interfaces.Animation;

/**
 * this class named PauseScreen is for creating a PauseScreen object.
 * pause the screen.
 * @author Ron Solomon
 */
public class LoseScreen implements Animation {
    private boolean stop;
    private int score;
    /**
     * this method is the constructor.
     * @param score is the score.
     */
    public LoseScreen(int score) {
        this.stop = false;
        this.score = score;
    }
    @Override
    public void doOneFrame(DrawSurface d) {
        d.drawText(10, d.getHeight() / 2,
                "Game Over. your score is :" + score + "", 32);
    }
    @Override
    public boolean shouldStop() {
        return this.stop;
    }
}
