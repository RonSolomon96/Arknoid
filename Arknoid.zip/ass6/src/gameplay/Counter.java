package gameplay;
//315589507

/**
 * this class named Counter is for creating a Counter object.
 *Counter is a simple class that is used for counting things
 * @author Ron Solomon
 */
public class Counter {
    private int value;
    /**
     * this method is the constructor.
     */
    public Counter() {
        this.value = 0;
    }
    /**
     * this method is the constructor.
     * @param x is the start value
     */
    public Counter(int x) {
        this.value = x;
    }
    /**
     * this method is to increase values.
     * @param number is the number to increase with.
     */
    void increase(int number) {
        this.value = this.value + number;
    }
    /**
     * this method is to subtract number from current count.
     * @param number is the number to decrease with.
     */
    void decrease(int number) {
        this.value = this.value - number;
    }
    /**
     * this method is to get current count.
     * @return the value.
     */
    int getValue() {
        return this.value;
    }
}
