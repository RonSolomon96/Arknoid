package gameplay;
//315589507
import basicshapes.Ball;
import gameobjects.Block;
import interfaces.HitListener;


/**
 * this class named BlockRemover is for creating a BlockRemover object.
 * a BlockRemover is in charge of removing blocks from the game, as well as keeping count
 * of the number of blocks that remain.
 * @author Ron Solomon
 */
public class BlockRemover implements HitListener {
    private GameLevel game;
    private Counter remainingBlocks;
    /**
     * this method is thr constructor.
     * @param game is the game of the ball.
     * @param remainingBlocks is the remaining blocks count
     */
    public BlockRemover(GameLevel game, Counter remainingBlocks) {
        this.game = game;
        this.remainingBlocks = remainingBlocks;
    }
    /**
     * this method draw the ball on the given DrawSurface.
     * @param beingHit is the block that has been hit.
     * @param hitter is the hitter ball .
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        beingHit.removeFromGame(game);
        this.remainingBlocks.decrease(1);
    }
}
