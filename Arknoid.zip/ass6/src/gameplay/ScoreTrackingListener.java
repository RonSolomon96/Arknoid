package gameplay;
//315589507

import basicshapes.Ball;
import gameobjects.Block;
import interfaces.HitListener;

/**
 * this class named ScoreTrackingListener is for creating a ScoreTrackingListener object.
 * a ScoreTrackingListener is in charge of tracking scores
 * @author Ron Solomon
 */
public class ScoreTrackingListener implements HitListener {
    private Counter currentScore;
    /**
     * constructor
     * @param scoreCounter is the score counter
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }
@Override
    public void hitEvent(Block beingHit, Ball hitter) {
        currentScore.increase(5);
    }
}