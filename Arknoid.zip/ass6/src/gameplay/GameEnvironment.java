package gameplay;
//ID : 315589507
import java.util.ArrayList;
import java.util.List;
import basicshapes.Line;
import basicshapes.Point;
import interfaces.Collidable;

/**
 * this class named GameEnvironment is for creating a GameEnvironment object.
 * include all the game objects.
 * The ball will know the game environment, and will use it to check for collisions and direct its movement.
 * @author Ron Solomon
 */
public class GameEnvironment {
    private List<Collidable> collideList;
    //constructor
    /**
     * aGameEnvironment constructor.
     */
    public GameEnvironment() {
        this.collideList = new ArrayList<>();
    }
    /**
     * add the given collidable to the environment.
     * @param c collidable item
     */
    public void addCollidable(Collidable c) {
        this.collideList.add(c);
    }
    /**
     * get Sprite list.
     * @return collidable list
     */
    public List<Collidable> getCollideList() {
        return this.collideList;
    }
    /**
     * Assume an object moving from line.start() to line.end().
     * If this object will not collide with any of the collidables
     * in this collection, return null. Else, return the information
     * about the closest collision that is going to occur.
     * @param trajectory trajectory line.
     * @return the collision info
     */

    public CollisionInfo getClosestCollision(Line trajectory) {
        List<Collidable> collideList2 = new ArrayList<>(this.collideList);
        if (collideList2.isEmpty()) {
            return null;
        }
        double epsilon = Math.pow(10, -13);
        //set minimum distance
        double dMin = trajectory.start().distance(trajectory.end());
        //set minimum point
        Point pMin = new Point(0, 0);
        int index = 0;
        int counter = 0;
        //for loop to find the next collision point
        for (int i = 0; i < collideList2.size(); i++) {
            //get the closest intersection point to the Start Of the Line
            Point p = trajectory.closestIntersectionToStartOfLine(collideList2.get(i).getCollisionRectangle());
            if (p == null) {
                continue;
            } else {
                double dCompare = p.distance(trajectory.start());
                //if there is an intersection count
                counter = counter + 1;
                //check the min distance and change if necessary
                if (dMin > dCompare || Math.abs(dMin - dCompare) < epsilon) {
                    dMin = p.distance(trajectory.start());
                    index = i;
                    pMin = p;
                }
            }
        }
        if (counter == 0) {
            return null;
        } else {
            //return the coCollisionInfo
            return new CollisionInfo(pMin, this.collideList.get(index));
        }
    }
}

