package gameplay;

import biuoop.GUI;
import biuoop.KeyboardSensor;
import interfaces.LevelInformation;

import java.util.List;

/**
 * this class named game is for creating a game object.
 * a game has the initialize and run methods wich creates the game and runs .
 * @author Ron Solomon
 */
public class GameFlow {
    private biuoop.KeyboardSensor ks;
    private AnimationRunner ar;
    private GUI gui;
    private Counter score;

    /**
     * this method is the constructor.
     *
     * @param ks  is the keyboard.
     * @param ar  is the animation runner.
     * @param gui is the animation runner.
     */
    //
    public GameFlow(AnimationRunner ar, KeyboardSensor ks, GUI gui) {
        this.gui = gui;
        this.ar = ar;
        this.ks = ks;
        this.score = new Counter();
    }

    /**
     * this method runs the levels.
     *
     * @param levels is the levels.
     */
    public void runLevels(List<LevelInformation> levels) {
        int count = 0;
        for (LevelInformation levelInfo : levels) {
            GameLevel level = new GameLevel(levelInfo, this.gui, this.ks, score);
            level.initialize();
            while (level.getCounterBlock().getValue() != 0 && level.getCounterBall().getValue() != 0) {
                level.run();
            }

            if (level.getCounterBall().getValue() == 0) {
                count = 1;
                this.ar.run(new KeyPressStoppableAnimation(this.ks, "space", new LoseScreen(score.getValue())));
                gui.close();
                break;
            }
        }
        if (count != 1) {
            this.ar.run(new KeyPressStoppableAnimation(this.ks, "space", new WinScreen(score.getValue())));
            gui.close();
        }
    }
}

