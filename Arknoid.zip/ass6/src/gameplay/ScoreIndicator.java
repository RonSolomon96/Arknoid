package gameplay;

import biuoop.DrawSurface;
import interfaces.Sprite;
/**
 * this class named ScoreIndicator is for creating a ScoreIndicator object.
 * a ScoreIndicator is in charge of keeping count of the score of the game.
 * @author Ron Solomon
 */
public class ScoreIndicator implements Sprite {
    private Counter scores;
    /**
     * this method is the constructor.
     * @param scores is the score
     */
    public ScoreIndicator(Counter scores) {
        this.scores = scores;
    }
    @Override
    public void drawOn(DrawSurface d) {
       d.drawText(350, 25, "score:" + scores.getValue() + "", 20);
    }

    @Override
    public void timePassed() {

    }
    /**
     * this method add sprite to the game.
     * @param g is the game
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);

    }
}
