package gameplay;
//315589507

import biuoop.DrawSurface;
import interfaces.Animation;

/**
 * this class named PauseScreen is for creating a PauseScreen object.
 * pause the screen.
 * @author Ron Solomon
 */
public class PauseScreen implements Animation {
    private boolean stop;
    /**
     * this method is the constructor.
     */
    public PauseScreen() {
        this.stop = false;
    }
    @Override
    public void doOneFrame(DrawSurface d) {
        d.drawText(10, d.getHeight() / 2, "paused -- press space to continue", 32);
    }
    @Override
    public boolean shouldStop() {
        return this.stop;
    }
}
