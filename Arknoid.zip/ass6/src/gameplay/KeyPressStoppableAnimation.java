package gameplay;
//315589507

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import interfaces.Animation;

/**
 * this class named PauseScreen is for creating a PauseScreen object.
 * pause the screen.
 * @author Ron Solomon
 */
public class KeyPressStoppableAnimation implements Animation {
    private KeyboardSensor sensor;
    private String key;
    private Animation animation;
    private boolean stop;
    private boolean isAlreadyPressed;
    /**
     * this method is the constructor.
     * @param sensor is the keyboard.
     * @param key is the key.
     * @param animation is the animation.
     */
    public KeyPressStoppableAnimation(KeyboardSensor sensor, String key, Animation animation) {
        this.stop = false;
        this.animation = animation;
        this.key = key;
        this.sensor = sensor;
        this.isAlreadyPressed = true;
    }

    @Override
    public void doOneFrame(DrawSurface d) {
        animation.doOneFrame(d);
        if (sensor.isPressed(key)) {
            if (!this.isAlreadyPressed) {
                this.stop = true;
            }
        }
        this.isAlreadyPressed = false;
        }
    @Override
    public boolean shouldStop() {
        return this.stop;
    }
}
