package gameplay;
//315589507
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
import interfaces.Animation;
/**
 * this class named AnimationRunner is for creating a AnimationRunner object.
 * runs an Animation object.
 * @author Ron Solomon
 */
public class AnimationRunner {
    private GUI gui;
    private int framesPerSecond;
    private  Sleeper sleeper;
    /**
     * this method is the constructor.
     * @param gui is the gui object.
     * @param framesPerSecond is the framesPerSecond value.
     */
    public AnimationRunner(GUI gui, int framesPerSecond) {
        this.gui = gui;
        this.framesPerSecond = framesPerSecond;
        sleeper = new Sleeper();
    }
    /**
     * this method runs the given animation.
     * @param animation is the given animation object.
     */
    public void run(Animation animation) {
        int millisecondsPerFrame = 1000 / this.framesPerSecond;
        while (!animation.shouldStop()) {
            long startTime = System.currentTimeMillis(); // timing
            DrawSurface d = gui.getDrawSurface();
            animation.doOneFrame(d);
            gui.show(d);
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                this.sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }
}
