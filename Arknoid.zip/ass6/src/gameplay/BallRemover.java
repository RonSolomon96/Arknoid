package gameplay;
//315589507
import basicshapes.Ball;
import gameobjects.Block;
import interfaces.HitListener;


/**
 * this class named BlockRemover is for creating a BlockRemover object.
 * a BlockRemover is in charge of removing blocks from the game, as well as keeping count
 * of the number of blocks that remain.
 * @author Ron Solomon
 */
public class BallRemover implements HitListener {
    private GameLevel game;
    private Counter remainingBalls;
    /**
     * this method is thr constructor.
     * @param game is the game of the ball.
     * @param remainingBalls is the remaining balss count
     */
    public BallRemover(GameLevel game, Counter remainingBalls) {
        this.game = game;
        this.remainingBalls = remainingBalls;
    }
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        hitter.removeFromGame(game);
        this.remainingBalls.decrease(1);
    }
}