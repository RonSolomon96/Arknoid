package gameplay;
//ID : 315589507
import biuoop.DrawSurface;
import interfaces.Sprite;
import java.util.ArrayList;
import java.util.List;
/**
 * aGameEnvironment constructor.
 */
public class SpriteCollection {
    private List<Sprite> spriteList;
//constructor
    /**
     * aGameEnvironment constructor.
     */
    public SpriteCollection() {
        this.spriteList = new ArrayList<>();
    }
    /**
     * add the given Sprite to the list.
     * @param s Sprite item
     */
    public void addSprite(Sprite s) {
        this.spriteList.add(s);
    }
    /**
     * call timePassed() on all sprites.
     */
    public void notifyAllTimePassed() {
        List<Sprite> sprites2 = new ArrayList<>(this.spriteList);
        for (Sprite sprite : sprites2) {
            sprite.timePassed();
        }
    }
    /**
     * get Sprite list.
     * @return sprite list
     */
    public List<Sprite> getSprite() {
        return this.spriteList;
    }
    /**
     * call drawOn(d) on all sprites.
     * @param d is the surface.
     */
    public void drawAllOn(DrawSurface d) {
        for (Sprite sprite : this.spriteList) {
            sprite.drawOn(d);
        }
    }
}
