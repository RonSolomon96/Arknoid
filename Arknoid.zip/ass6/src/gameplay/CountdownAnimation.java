package gameplay;
//315589507


import biuoop.DrawSurface;
import biuoop.Sleeper;
import interfaces.Animation;

import java.awt.Color;

/**
 * this class named CountdownAnimation is for creating a CountdownAnimation class.
 * The CountdownAnimation will display the given gameScreen,
 *  for numOfSeconds seconds, and on top of them it will show
 *  a countdown from countFrom back to 1, where each number will
 *  appear on the screen for (numOfSeconds / countFrom) seconds, before
 *  it is replaced with the next one.
 * @author Ron Solomon
 */

public class CountdownAnimation implements Animation {
    private double numOfSeconds;
    private int countFrom;
    private SpriteCollection gameScreen;
    private boolean stop;
    /**
     * this method is the constructor.
     * @param numOfSeconds is the number of second to count.
     * @param countFrom is the start value
     * @param gameScreen is the sprites collection .
     */
    public CountdownAnimation(double numOfSeconds, int countFrom, SpriteCollection gameScreen) {
        this.numOfSeconds = numOfSeconds * 666;
        this.countFrom = countFrom;
        this.gameScreen = gameScreen;
        this.stop = false;
    }
    @Override
    public void doOneFrame(DrawSurface d) {
        this.gameScreen.drawAllOn(d);
        d.setColor(Color.gray);
        d.drawText(d.getWidth() / 2, d.getHeight() / 2, "" + countFrom + "", 32);
        if (countFrom != 3) {
            Sleeper sleeper = new Sleeper();
            sleeper.sleepFor((long) numOfSeconds);
        }
        if (this.countFrom == 0) {
            this.stop = true;
        }
        this.countFrom = this.countFrom - 1;
    }
    @Override
    public boolean shouldStop() {
        return this.stop;
    }
}

