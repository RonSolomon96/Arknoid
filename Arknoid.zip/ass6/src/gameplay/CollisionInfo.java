package gameplay;
//ID : 315589507

import basicshapes.Point;
import interfaces.Collidable;

/**
 * this class named CollisionInfo is for creating a CollisionInfo object.
 * include objects CollisionInfo with the ball .
 * @author Ron Solomon
 */
public class CollisionInfo {
    private Point collisionPoint;
    private Collidable collisionObject;
    //constructor.
    /**
     * CollisionInfo constructor.
     * @param collisionPoint the collision point
     * @param collisionObject the type of object
     */
    public CollisionInfo(Point collisionPoint, Collidable collisionObject) {
        this.collisionObject = collisionObject;
        this.collisionPoint = collisionPoint;
    }
    /**
     * @return the point at which the collision occurs.
     */
    public Point collisionPoint() {
        return this.collisionPoint;
    }
    /**
     * @return the collidable object involved in the collision.
     */
    public Collidable collisionObject() {
        return this.collisionObject;
    }
}
