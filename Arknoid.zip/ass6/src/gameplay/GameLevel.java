package gameplay;
//ID : 315589507
import basicshapes.Ball;
import basicshapes.Point;
import basicshapes.Rectangle;
import basicshapes.Velocity;
import biuoop.DrawSurface;
import biuoop.GUI;
import gameobjects.Block;
import gameobjects.Paddle;
import gameobjects.Painter;
import interfaces.Animation;
import interfaces.Collidable;
import interfaces.LevelInformation;
import interfaces.Sprite;
import java.awt.Color;
import java.util.List;
/**
 * this class named game is for creating a game object.
 * a game has the initialize and run methods wich creates the game and runs .
 * @author Ron Solomon
 */

public class GameLevel implements Animation {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;
    private Counter counterBlock;
    private Counter counterBall;
    private Counter score;
    private AnimationRunner runner;
    private biuoop.KeyboardSensor keyboard;
    private boolean running;
    private LevelInformation level;
//constructor
    /**
     * Game constructor.
     * @param level is the level to play.
     * @param gui is the gui to play.
     * @param keyboard is the keyboard to play.
     * @param score is the score count.
     */
    public GameLevel(LevelInformation level, GUI gui, biuoop.KeyboardSensor keyboard, Counter score) {
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.counterBlock = new Counter();
        this.counterBall = new Counter();
        this.score = score;
        this.level = level;
        this.gui = gui;
        this.keyboard = keyboard;
    }
    /**
     * add collidable.
     * @param c is the collidable item.
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }
    /**
     * add sprite.
     * @param s is the collidable item.
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }
    /**
     * get sprites.
     * @return sprites
     */
    public SpriteCollection getSprites() {
    return this.sprites;
    }
    /**
     * Initialize a new game: create the Blocks and Ball (and Paddle)
     * and add them to the game.
     */
    public void initialize() {
        BlockRemover p = new BlockRemover(this, counterBlock);
        BallRemover p2 = new BallRemover(this, counterBall);
        ScoreTrackingListener p3 = new ScoreTrackingListener(this.score);
        //set screen color
        this.addSprite(this.level.getBackground());
        //set balls and insert to game
        List<Velocity> ballV  = this.level.initialBallVelocities();
        for (int i = 0; i < level.numberOfBalls(); i++) {
            Ball ball1 = new Ball(400, 540, 5, level.ballColor());
            ball1.setVelocity(ballV.get(i));
            counterBall.increase(1);
            ball1.addToGame(this);
            ball1.setGameEnvironment(this.environment);
        }
        //set key board and paddle
        Rectangle recPaddle = new Rectangle(new Point(400 - (double) (level.paddleWidth() / 2), 555),
                level.paddleWidth(), 5);
        Paddle paddle = new Paddle(keyboard, recPaddle);
        paddle.setColor(new Color(0,  150, 100));
        paddle.setPaddleWidth(level.paddleWidth());
        paddle.setStep(level.paddleSpeed());
        paddle.addToGame(this);
        //set borders
        Block b1 = new Block(new Rectangle(new Point(0, 0), 800, 40));
        b1.setColor(Color.gray);
        b1.addToGame(this);
        Block b3 = new Block(new Rectangle(new Point(0, 40), 40, 520));
        b3.setColor(Color.gray);
        b3.addToGame(this);
        Block b4 = new Block(new Rectangle(new Point(760, 40), 40, 520));
        b4.setColor(Color.gray);
        b4.addToGame(this);
        //ball killer block
        Block b2 = new Block(new Rectangle(new Point(0, 560), 800, 40));
        b2.setColor(new Color(50, 22, 20).brighter().brighter().brighter());
        b2.addToGame(this);
        b2.addHitListener(p2);
        //score block
        Block b5 = new Block(new Rectangle(new Point(0, 0), 800, 30));
        b5.setColor(Color.gray.brighter());
        this.addSprite(b5);
        ScoreIndicator p4 = new ScoreIndicator(this.score);
        p4.addToGame(this);
        //level name
        Painter painter = new Painter(550, 25, 20, this.level.levelName());
        this.addSprite(painter);
        //set in game blocks
        List<Block> blocksL = level.blocks();
        for (Block block : blocksL) {
            block.addHitListener(p);
            block.addHitListener(p3);
            block.addToGame(this);
            counterBlock.increase(1);
        }
            this.runner = new AnimationRunner(this.gui, 60);
    }
    /**
     * Run the game -- start the animation loop.
     */
    public void run() {
        this.runner.run(new CountdownAnimation(1, 3, this.sprites));
        this.running = true;
        // use our runner to run the current animation -- which is one turn of
        // the game.
        this.runner.run(this);
        }
    /**
     * remove a collidable from the list.
     * @param c the object we want to remove.
     */
    public void removeCollidable(Collidable c) {
    environment.getCollideList().remove(c);
    }
    /**
     * remove a sprite from the list.
     * @param s the object we want to remove.
     */
    public void removeSprite(Sprite s) {
        sprites.getSprite().remove(s);
    }

    @Override
    public void doOneFrame(DrawSurface d) {
            //this.background.drawOn(d);
            this.sprites.drawAllOn(d);
            this.sprites.notifyAllTimePassed();
                if (counterBlock.getValue() == 0) {
                    this.score.increase(100);
                    this.running = false;
                }
                if (counterBall.getValue() == 0) {
                    this.running = false;
                }
        if (this.keyboard.isPressed("p")) {
            this.runner.run(new KeyPressStoppableAnimation(this.keyboard, "space", new PauseScreen()));
        }
            }
    @Override
    public boolean shouldStop() {
        return !this.running;
    }
    /**
     * get the blocks count.
     * @return counter of blocks.
     */
    public Counter getCounterBlock() {
        return this.counterBlock;
    }
    /**
     * get the balls count.
     * @return counter of balls.
     */
    public Counter getCounterBall() {
        return this.counterBall;
    }
}
